module.exports = {
  globalSetup: './src/spec/mongo-setup.js',
  globalTeardown: './src/spec/teardown.js',
  testEnvironment: './src/spec/mongo-environment.js'
};