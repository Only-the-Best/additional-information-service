const { MongoClient } = require('mongodb');
const mongoose = require('mongoose');



describe('the database (mongoDB)', () => {

  let connection;
  let db;

  beforeAll(async () => {
    connection = await MongoClient.connect(global.__MONGO_URI__);
    db = await connection.db(global.__MONGO_DB_NAME__);
  });

  afterAll(async () => {
    await connection.close();
  });


  const uri = 'mongodb://localhost/test';

  const db = mongoose.connect(
    uri,
    { useNewUrlParser: true },
  );



  const testSchema = new mongoose.Schema({
    _id: String,
    address: String,
    city: String,
    zip: Number,
    zestimate: [Number],
    beds: Number,
    baths: Number,
    sqFt: Number,
    status: String,
    taxAssessment: Number,
  });

  const Test = mongoose.model('Test', testSchema);
  Test.create(seedFunc());

  test('something', () => {
    console.log('ran');
  });

  Test.collection.drop();
  mongoose.connection.close();


});